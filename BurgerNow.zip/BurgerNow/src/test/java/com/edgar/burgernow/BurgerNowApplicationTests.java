package com.edgar.burgernow;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class BurgerNowApplicationTests {

	@Test
	void contextLoads() {
	}

}
