/* Copyright © 2005 - 2014 Annpoint, s.r.o.
   Use of this software is subject to license terms. 
   http://www.daypilot.org/
*/

package org.daypilot.demo.db;

import java.util.ArrayList;

public class Table extends ArrayList<Row> {

	/**
	 * 
	 */
	private static final long serialVersionUID = 6164269594608519475L;

}
